import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Recruiter Review Log — RedefinedHire AI", page_icon="📝", layout="wide")
st.title("📝 Recruiter Review Log (HITL Trace)")
st.caption("Record the human-in-the-loop review outcome for each candidate. No PII required; use a unique candidate ID.")

with st.expander("Guidance"):
    st.markdown("""
    - Do **not** store PII in this demo. Use an internal candidate ID only.
    - Capture the **risk band** from the main page (Low/Medium/High) and a quick rationale.
    - This is an **in-memory log** for demo purposes. In production, write to an audit store with RBAC.
    """)

if "review_log" not in st.session_state:
    st.session_state["review_log"] = []

col1, col2, col3 = st.columns(3)
with col1:
    candidate_id = st.text_input("Candidate ID", placeholder="e.g., C-2025-001")
with col2:
    reviewer = st.text_input("Reviewer name/initials", placeholder="e.g., AK or J.Smith")
with col3:
    risk_band = st.selectbox("Risk band", ["Low", "Medium", "High"], index=1)

decision = st.radio("Decision", ["Proceed", "Defer", "Reject"], horizontal=True)
rationale = st.text_area("Rationale/Notes", placeholder="Brief reason, conditions, or next steps")

if st.button("Add review entry"):
    if not candidate_id or not reviewer:
        st.warning("Candidate ID and Reviewer are required.")
    else:
        st.session_state["review_log"].append({
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "candidate_id": candidate_id,
            "reviewer": reviewer,
            "risk_band": risk_band,
            "decision": decision,
            "rationale": rationale
        })
        st.success("Entry added (session only).")

st.markdown("---")
st.subheader("Review Log (session)")
df = pd.DataFrame(st.session_state["review_log"])
if df.empty:
    st.info("No entries yet.")
else:
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.download_button("Download review log (CSV)",
                       data=df.to_csv(index=False).encode("utf-8"),
                       file_name="review_log.csv",
                       mime="text/csv")