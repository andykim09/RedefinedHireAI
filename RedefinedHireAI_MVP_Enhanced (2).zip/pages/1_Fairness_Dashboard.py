import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Fairness Dashboard — RedefinedHire AI", page_icon="📊", layout="wide")
st.title("📊 Fairness Dashboard (AIR / 4-fifths)")
st.caption("Simulate selection rates and the Adverse Impact Ratio (AIR). Reference group is set to the group with the highest selection rate by default.")

with st.expander("How this works"):
    st.markdown("""
    - **Selection rate** = hires ÷ applicants.
    - **AIR** (adverse impact ratio) = lowest selection rate ÷ highest selection rate.
    - **4/5ths (0.80) rule:** If AIR < 0.80, potential adverse impact. Investigate, validate, and mitigate.
    """)

col1, col2 = st.columns(2)
with col1:
    st.subheader("Group A")
    a_name = st.text_input("Group A name", value="Group A")
    a_app = st.number_input("Applicants (A)", min_value=0, value=100, step=1)
    a_sel = st.number_input("Selected/Hired (A)", min_value=0, value=30, step=1)

with col2:
    st.subheader("Group B")
    b_name = st.text_input("Group B name", value="Group B")
    b_app = st.number_input("Applicants (B)", min_value=0, value=100, step=1)
    b_sel = st.number_input("Selected/Hired (B)", min_value=0, value=20, step=1)

def safe_rate(selected, applicants):
    return (selected / applicants) if applicants else 0.0

rate_a = safe_rate(a_sel, a_app)
rate_b = safe_rate(b_sel, b_app)

hi_name, hi_rate = (a_name, rate_a) if rate_a >= rate_b else (b_name, rate_b)
lo_name, lo_rate = (b_name, rate_b) if rate_a >= rate_b else (a_name, rate_a)

air = (lo_rate / hi_rate) if hi_rate > 0 else 0.0
passes = air >= 0.80

st.markdown("---")
st.subheader("Results")
metrics = pd.DataFrame([
    {"Group": a_name, "Applicants": a_app, "Selected": a_sel, "Selection Rate": round(rate_a, 3)},
    {"Group": b_name, "Applicants": b_app, "Selected": b_sel, "Selection Rate": round(rate_b, 3)},
])
st.dataframe(metrics, use_container_width=True, hide_index=True)

st.markdown(f"**Highest selection rate:** {hi_name} = {hi_rate:.3f}")
st.markdown(f"**Lowest selection rate:** {lo_name} = {lo_rate:.3f}")
st.markdown(f"### AIR (lowest ÷ highest) = **{air:.3f}**")

if passes:
    st.success("AIR ≥ 0.80 — passes the 4/5ths rule (monitor, document, and keep auditing).")
else:
    st.error("AIR < 0.80 — potential adverse impact. Investigate causes, validate job-relatedness, and consider mitigations.")

# Optional: Log a snapshot for audit notes (local session only)
st.markdown("---")
st.subheader("Log a snapshot (local, demo)")
note = st.text_input("Optional note (e.g., cohort, time window, requisition)")
if "fairness_log" not in st.session_state:
    st.session_state["fairness_log"] = []

if st.button("Save snapshot"):
    entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "group_hi": hi_name, "rate_hi": round(hi_rate, 4),
        "group_lo": lo_name, "rate_lo": round(lo_rate, 4),
        "AIR": round(air, 4),
        "passes_4fifths": passes,
        "note": note
    }
    st.session_state["fairness_log"].append(entry)
    st.success("Saved (session only).")

if st.session_state.get("fairness_log"):
    df = pd.DataFrame(st.session_state["fairness_log"])
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.download_button("Download fairness log (CSV)",
                       data=df.to_csv(index=False).encode("utf-8"),
                       file_name="fairness_log.csv",
                       mime="text/csv")